# lcfg for Python

Convert LiteConfig to Python object.

将 lcfg 转换为 Python 对象。

___

This project is under development.

此项目正在开发中